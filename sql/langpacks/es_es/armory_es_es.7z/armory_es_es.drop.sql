/*
	This will drop all `*_es_es` tables in `armory` DB! Be carefull!
*/

ALTER TABLE `armory_achievement` DROP `name_es_es` ,
DROP `description_es_es` ,
DROP `titleReward_es_es` ;

ALTER TABLE `armory_achievement_category` DROP `name_es_es`;

ALTER TABLE `armory_achievement_criteria` DROP `name_es_es` ;

ALTER TABLE `armory_classes` DROP `name_es_es`;

ALTER TABLE `armory_enchantment` DROP `text_es_es` ;

ALTER TABLE `armory_faction` DROP `name_es_es` ,
DROP `description_es_es` ;

ALTER TABLE `armory_glyphproperties` DROP `name_es_es` ,
DROP `description_es_es` ;

ALTER TABLE `armory_instance_data` DROP `name_es_es` ;

ALTER TABLE `armory_instance_template` DROP `name_es_es` ;

ALTER TABLE `armory_itemsetinfo` DROP `name_es_es` ;

ALTER TABLE `armory_maps` DROP `name_es_es` ;

ALTER TABLE `armory_professions` DROP `name_es_es` ;

ALTER TABLE `armory_races` DROP `name_es_es` ;

ALTER TABLE `armory_reputation_ranks` DROP `name_es_es` ;

ALTER TABLE `armory_skills` DROP `name_es_es` ,
DROP `description_es_es` ;

ALTER TABLE `armory_spell` DROP `SpellName_es_es` ,
DROP `Rank_es_es` ,
DROP `Description_es_es` ,
DROP `Tooltip_es_es` ;

ALTER TABLE `armory_string` DROP `string_es_es` ;

ALTER TABLE `armory_talenttab` DROP `name_es_es` ;

ALTER TABLE `armory_titles` DROP `title_M_es_es` ,
DROP `title_F_es_es` ;